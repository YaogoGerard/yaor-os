# YAOR OS — Documentation

Documentation industrielle du projet YAOR OS.

## Structure
- `01-product/` — Pourquoi le projet existe
- `02-requirements/` — Ce que le système doit faire
- `03-architecture-hld/` — Architecture haut niveau
- `04-design-lld/` — Design détaillé
- `05-ui-ux/` — Interface et expérience utilisateur
- `06-testing/` — Vérification et validation

## Principe
> **Reuse what exists. Prefer Rust when suitable. Build what is missing.**

YAOR utilise le noyau Linux comme fondation, réutilise les composants open source appropriés et privilégie les implémentations Rust lorsqu'elles sont suffisamment adaptées et matures.
