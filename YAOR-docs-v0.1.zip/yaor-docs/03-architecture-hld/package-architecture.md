# Package Architecture

YAOR ne réécrit pas automatiquement le système de packaging Linux.

```text
YAOR
  |
Package integration layer
  |
Existing package ecosystem
  |
Packages / repositories
```

APT/dpkg peuvent être utilisés si cette solution répond aux besoins de la première version. Une couche YAOR spécifique peut être ajoutée ultérieurement pour l'intégration, la configuration et les métadonnées.
