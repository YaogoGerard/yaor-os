# Deployment & Operations

## Build

```text
Sources -> Toolchain -> Root filesystem -> Linux kernel -> Initramfs -> Filesystem image -> ISO
```

## Développement
La cible de test initiale est QEMU.

## CI
La CI DEVRAIT vérifier le formatage Rust, exécuter les tests, construire les composants, construire l'image, tester le boot et conserver les artefacts.

## Reproductibilité
Les versions et sources utilisées doivent être explicitement définies.
