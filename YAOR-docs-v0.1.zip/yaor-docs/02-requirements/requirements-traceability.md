# Requirements Traceability Matrix

| Requirement | Architecture | Test |
|---|---|---|
| REQ-SW-001 | Linux kernel | TEST-SYS-001 |
| REQ-SW-002 | Component selection | TEST-ARCH-001 |
| REQ-SW-003 | Component selection | TEST-ARCH-002 |
| REQ-SW-004 | Component selection | TEST-ARCH-003 |
| REQ-SW-005 | Graphics architecture | TEST-GFX-001 |
| REQ-SW-006 | Desktop architecture | TEST-DESK-001 |
| REQ-SW-007 | Desktop architecture | TEST-DESK-002 |
| REQ-SW-008 | UI/UX | TEST-UI-001 |
| REQ-SW-009 | UI/UX | TEST-UI-002 |
| REQ-SW-010 | UI/UX | TEST-UI-003 |
| REQ-SW-011 | Plugin system | TEST-PLUGIN-001 |
| REQ-SW-012 | Accessibility architecture | TEST-A11Y-001 |
| REQ-SW-013 | Accessibility architecture | TEST-A11Y-002 |
| REQ-SW-014 | Component selection | TEST-ARCH-004 |
| REQ-SW-015 | Config engine | TEST-CONFIG-001 |
| REQ-SW-016 | Deployment/build | TEST-BUILD-001 |
| REQ-SW-017 | Deployment/build | TEST-BOOT-001 |
| REQ-SW-018 | Testing strategy | TEST-TRACE-001 |
