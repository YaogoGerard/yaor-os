# System Services — LLD

Chaque service doit préciser responsabilité, dépendances, interface, démarrage, arrêt, erreurs, permissions et stratégie de remplacement.

YAOR ne crée pas un service personnalisé lorsqu'un service existant adapté répond au besoin sans justification contraire.
